/*
	Parker Gray
	CSC 340 Programming Methodology Section #01
	11/10/16
*/

#include "vector_double.h"

int main()
{
    vector_double v1;
    v1.resizePointer(1); //resize pointer to have a size of 1
    v1.insertValue(1.1, 0); //copy 1.1 to the first index
    vector_double v2;
    vector_double v3(v1);
    cout << v3 << endl; //check to see if v3 correctly copies v1

}
