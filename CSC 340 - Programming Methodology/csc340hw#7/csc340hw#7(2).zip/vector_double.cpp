/*
	Parker Gray
	CSC 340 Programming Methodology Section #01
	11/10/16
*/

#include "vector_double.h"

vector_double::~vector_double() //destructor
{
    if(pointer_double != NULL){
        delete [] pointer_double;
        pointer_double = NULL; //reinitialize with default constructor's parameters
        indexesused = 0;
        totalcapacity = 1;
    }
}

vector_double::vector_double() //default constructor
{
    pointer_double = NULL;
    indexesused = 0;
    totalcapacity = 1;
}

vector_double::vector_double(const vector_double& instance) //copy constructor
{
    indexesused = instance.indexesused + 1;
    totalcapacity = instance.totalcapacity + 1;
    if(indexesused <= 0){ //if zero indexes are being used
        pointer_double = NULL; //then the pointer must be null, because there's no values assigned to it
    }
    else{ //otherwise there must be some values inside of the pointer
        try{
            pointer_double = new double [indexesused]; //try to set pointer_double to a new pointer with a size of the number of used indexes in pointer_double
        }
        catch (bad_alloc & ba)
        {
            cerr<<"vector_double::vector_double(const vector_double&): " << ba.what() << endl;
        }
        for(int i = 0; i < indexesused; i++){
            pointer_double[i] = instance.pointer_double[i]; //set all of pointer_double's indexes to have the same value as our instance's pointer_double.
        }
    }
}

vector_double vector_double::operator=(const vector_double& rhs) //assignment operator
{
    if(indexesused > 0){ //if indexes being used is greater than zero
        delete [] pointer_double; //release the old memory that is held by pointer_double
    }
    indexesused = rhs.indexesused; //get the pointer on the right hand side of the = operator's values
    if(indexesused <= 0){ //if the new value of indexes used is zero
        pointer_double = NULL; //the pointer_double must be NULL
    }else{
        try{
            pointer_double = new double [indexesused + 1]; //create a new pointer just like the copy constructor function.
        }
        catch (bad_alloc & ba)
        {
            cerr<<"vector_double::vector_double(const vector_double&): " << ba.what() << endl;
        }
        for(int i = 0; i < indexesused; i++){
            pointer_double[i] = rhs.pointer_double[i]; //set the new pointer_double's values to the values on the right hand side of the = operator
        }
    }
    return (*this); //return the result
}


int vector_double::getCapacity()
{
    return totalcapacity; //returns how many numbers could be held inside of pointer_double, ie its capacity.
}

bool vector_double::isEmpty()
{
    if(indexesused == 0){ //is the amount of indexes used empty to begin with?
        return true; //if so, we have no reason to continue. we already know the pointer is empty. it contains no values.
    }else{
        return false;
        }
}


int vector_double::sizeVector()
{
    return indexesused;
}

void vector_double::insertValue(double value, int position)
{
    if(indexesused == totalcapacity){ //if every spot in the vector is filled
        indexesused++; //rather than having to set each future temppointer as temppointer = new double [indexesused + 1], I iterate indexesused immediately to avoid repetition.
        if(position = 0){ //if we want to place a value at the front of the pointer, then we have to move all of the other values forward in the pointer by one.
            double * temppointer = new double [indexesused];
            for(int i = 0; i < indexesused; i++){
                temppointer[i+1] = pointer_double[i]; //this moves all indexes at index i up one value for temppointer..
            }
            temppointer[0] = value; //put the value at its position given in the argument
            pointer_double = temppointer;
            delete [] temppointer;
        }else if(position > 0 && position < indexesused){ //if the position is in any point between endpoints of pointer_double, then
            double * temppointer1 = new double [indexesused];
            for(int i = position; i < indexesused; i++){ //move all values at position or greater than position to the right by one.
                temppointer1[i+1] = pointer_double[i]; //this moves all indexes at index i up one value.
            }
            temppointer1[position] = value;
            pointer_double = temppointer1;
            delete [] temppointer1;
        }else if(position > indexesused){ //if we want to place a value past all of the indexes that currently occupy values...
            double * temppointer2 = new double [indexesused + 1];
            for(int i = 0; i < indexesused + 1; i++){
                temppointer2[i] = pointer_double[i];
            }
            temppointer2[position] = value;
            delete [] temppointer2;
        }
    }else{
        cout << "Not a valid position because position does not fit the size or capacity of the pointer." << endl;
    }
}

void vector_double::popBack()
{
    double * temppointer = new double [indexesused-1];
    for(int i = 0; i > indexesused-1; i++){ //start at the 'end' of the pointer's capacity. decrement until we find an index that is being used
        temppointer[i] = pointer_double[i];
        }
    pointer_double = temppointer;
    delete [] temppointer;
}

void vector_double::pushBack(double value)
{
    double * temppointer = new double [indexesused + 1];
    for(int i = 0; i < indexesused; i++){
            temppointer[i] = pointer_double[i];
        }
    temppointer[indexesused + 1] = value;
    pointer_double = temppointer;
    delete [] temppointer;
}

void vector_double::resizePointer(int newsize)
{
    if(newsize < indexesused){ //if there exist values outside of newsize's integer in the current pointer_double
            double * temppointer = new double [newsize]; //create a temporary pointer with capacity of newsize
                for(int i = 0; i < newsize; i++){
                    temppointer[i] = pointer_double[i]; //apply pointer_double's values to temppointer
                }
                pointer_double = temppointer; //after completing temppointer, set pointer_double to point to temppointer
                delete [] temppointer;
                indexesused = newsize;
                totalcapacity = newsize;
            }else{
        indexesused = newsize; //totalcapacity does not need 'trimming' because newsize is either greater or equal to it.
        totalcapacity = newsize;
    }
}

void vector_double::shrinkToFit()
{
    if(indexesused = totalcapacity){ //if pointer_double is already 'shrunken to fit'
        cout << "Already shrunk to fit!" << endl;
    }else{
        resizePointer(indexesused); //use resizePointer to take care of the shrinking
    }
}

ostream& operator<<(ostream& outS, vector_double& pointer){
    for(int i = 0; i < pointer.indexesused; i++){
        cout << pointer.pointer_double[i] << endl;
    }
}
